const path = require("node:path");
const { execFileSync } = require("node:child_process");

module.exports = {
  outDir: process.env.OMI_BUILD_OUT_DIR || "out-omi",
  packagerConfig: {
    electronZipDir: process.env.OMI_ELECTRON_ZIP_DIR || undefined,
    asar: true,
    prune: false,
    afterCopy: [async ({ buildPath, platform }) => {
      // OneDrive's read-only directory attribute is copied into staging. ASAR
      // must be able to remove that staged tree after creating the archive.
      if (platform === "win32") {
        execFileSync("attrib.exe", ["-R", buildPath], { windowsHide: true });
        execFileSync("attrib.exe", ["-R", path.join(buildPath, "*"), "/S", "/D"], { windowsHide: true });
      }
    }],
    name: "OMI",
    executableName: "OMI",
    icon: process.env.OMI_ICON_PATH || (process.env.OMI_TARGET_PLATFORM === "darwin" ? undefined : path.join(__dirname, "electron", "assets", "omi.ico")),
    protocols: [{ name: "OMI Auth", schemes: ["smbsystem"] }],
    ignore: (relativePath) => {
      if (!relativePath) return false;
      const topLevel = relativePath.replaceAll("\\", "/").split("/")[1];
      return !["package.json", "electron", "dist"].includes(topLevel);
    },
  },
  makers: [
    {
      name: "@electron-forge/maker-squirrel",
      config: {
        name: "OMI",
        title: "OMI",
        setupExe: "OMI-Instalar.exe",
        setupIcon: process.env.OMI_ICON_PATH || path.join(__dirname, "electron", "assets", "omi.ico"),
        noMsi: true,
      },
      platforms: ["win32"],
    },
    {
      name: "@electron-forge/maker-zip",
      platforms: ["win32", "darwin"],
    },
  ],
};
