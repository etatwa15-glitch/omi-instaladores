const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("desktopBridge", {
  openAuthUrl: (url) => ipcRenderer.invoke("native-open-auth", url),
  getAuthCallback: () => ipcRenderer.invoke("native-get-auth-callback"),
  onAuthCallback: (callback) => {
    const listener = (_event, url) => callback(url);
    ipcRenderer.on("native-auth-callback", listener);
    return () => ipcRenderer.removeListener("native-auth-callback", listener);
  },
});
