const { app, autoUpdater, BrowserWindow, dialog, ipcMain, Menu, net, protocol, session, shell } = require("electron");
const http = require("node:http");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { pathToFileURL } = require("node:url");
const { startAutoUpdates } = require("./auto-update.cjs");

const authScheme = "smbsystem";
const appOrigin = "app://bundle";
const distDir = path.resolve(__dirname, "..", "dist");
let mainWindow;
let pendingAuthUrl = null;
let loopbackReady = false;
const loopbackServers = [];

function handleSquirrelEvent() {
  if (process.platform !== "win32") return false;
  const event = process.argv[1];
  if (!["--squirrel-install", "--squirrel-updated", "--squirrel-uninstall", "--squirrel-obsolete"].includes(event)) return false;
  if (event !== "--squirrel-obsolete") {
    const updateExe = path.resolve(path.dirname(process.execPath), "..", "Update.exe");
    const action = event === "--squirrel-uninstall" ? "--removeShortcut" : "--createShortcut";
    const child = spawn(updateExe, [action, path.basename(process.execPath)], { detached: true, stdio: "ignore", windowsHide: true });
    child.on("error", (error) => console.error("Could not update OMI shortcuts:", error));
    child.unref();
  }
  app.quit();
  return true;
}

if (handleSquirrelEvent()) return;

protocol.registerSchemesAsPrivileged([
  { scheme: "app", privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

function isAuthCallback(value) {
  try {
    const url = new URL(value);
    return url.protocol === `${authScheme}:` && url.hostname === "auth" && url.pathname === "/callback";
  } catch {
    return false;
  }
}

function receiveAuthCallback(value) {
  if (!isAuthCallback(value)) return;
  pendingAuthUrl = value;
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
    mainWindow.webContents.send("native-auth-callback", value);
  }
}

function handleLoopbackCallback(request, response) {
  const url = new URL(request.url || "/", "http://localhost:8080");
  if (request.method !== "GET" || url.pathname !== "/" || (!url.searchParams.has("code") && !url.searchParams.has("error"))) {
    response.writeHead(404).end();
    return;
  }

  receiveAuthCallback(`smbsystem://auth/callback${url.search}`);
  response.writeHead(200, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'",
  });
  response.end("<!doctype html><html lang='es'><meta charset='utf-8'><title>OMI</title><body style='font-family:system-ui;text-align:center;padding:4rem'><h1>Vuelve a OMI</h1><p>El inicio de sesión ya regresó a la aplicación. Puedes cerrar esta pestaña.</p></body></html>");
}

function listenOnLoopback(host) {
  return new Promise((resolve, reject) => {
    const server = http.createServer(handleLoopbackCallback);
    server.once("error", reject);
    server.listen({ port: 8080, host, ipv6Only: host === "::1" }, () => {
      server.removeListener("error", reject);
      resolve(server);
    });
  });
}

async function startLoopbackCallback() {
  try {
    loopbackServers.push(await listenOnLoopback("::1"));
    loopbackServers.push(await listenOnLoopback("127.0.0.1"));
    loopbackReady = true;
  } catch (error) {
    for (const server of loopbackServers) server.close();
    loopbackServers.length = 0;
    console.error("Could not reserve localhost:8080 for Google sign-in:", error);
  }
}

if (process.defaultApp && process.argv[1]) {
  app.setAsDefaultProtocolClient(authScheme, process.execPath, [path.resolve(process.argv[1])]);
} else {
  app.setAsDefaultProtocolClient(authScheme);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", (_event, args) => {
    const callback = args.find(isAuthCallback);
    if (callback) receiveAuthCallback(callback);
    else if (mainWindow) mainWindow.focus();
  });
  app.on("open-url", (event, url) => {
    event.preventDefault();
    receiveAuthCallback(url);
  });

  app.whenReady().then(async () => {
    Menu.setApplicationMenu(null);
    if (process.platform === "win32") app.setAppUserModelId("com.squirrel.OMI.OMI");
    await startLoopbackCallback();
    // Bundled assets keep the same app:// URL between releases. Discard only HTTP cache,
    // preserving localStorage (including the theme) and the signed-in session.
    try {
      await session.defaultSession.clearCache();
    } catch (error) {
      console.error("Could not clear OMI asset cache:", error);
    }
    protocol.handle("app", (request) => {
      const url = new URL(request.url);
      if (url.hostname !== "bundle") return new Response("Not found", { status: 404 });
      const requested = decodeURIComponent(url.pathname);
      const candidate = path.resolve(distDir, `.${requested === "/" ? "/index.html" : requested}`);
      const relative = path.relative(distDir, candidate);
      if (relative.startsWith("..") || path.isAbsolute(relative)) return new Response("Forbidden", { status: 403 });
      return net.fetch(pathToFileURL(candidate).toString());
    });

    ipcMain.handle("native-open-auth", async (event, value) => {
      if (!mainWindow || event.sender !== mainWindow.webContents) throw new Error("Invalid window");
      const url = new URL(value);
      const supabaseLogin = url.protocol === "https:" && url.hostname.endsWith(".supabase.co") && url.pathname === "/auth/v1/authorize";
      const googleCalendar = url.protocol === "https:" && url.hostname === "accounts.google.com" && url.pathname === "/o/oauth2/v2/auth"
        && url.searchParams.get("redirect_uri") === "https://ipcvrbvffkzpohjtadql.supabase.co/functions/v1/google-calendar-callback"
        && url.searchParams.get("scope") === "https://www.googleapis.com/auth/calendar.app.created";
      if (!supabaseLogin && !googleCalendar) {
        throw new Error("Invalid sign-in URL");
      }
      if (supabaseLogin && !loopbackReady) throw new Error("No se pudo usar localhost:8080 para iniciar sesión. Cierra la aplicación que ocupa ese puerto y reinicia OMI.");
      await shell.openExternal(url.toString());
    });
    ipcMain.handle("native-get-auth-callback", (event) => {
      if (!mainWindow || event.sender !== mainWindow.webContents) return null;
      const url = pendingAuthUrl;
      pendingAuthUrl = null;
      return url;
    });

    mainWindow = new BrowserWindow({
      width: 1280,
      height: 800,
      minWidth: 900,
      minHeight: 620,
      title: "OMI",
      icon: path.join(__dirname, "assets", "omi.ico"),
      webPreferences: {
        preload: path.join(__dirname, "preload.cjs"),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
      },
    });
    mainWindow.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    mainWindow.webContents.on("will-navigate", (event, url) => {
      if (!url.startsWith(`${appOrigin}/`)) event.preventDefault();
    });
    void mainWindow.loadURL(`${appOrigin}/`);
    startAutoUpdates({ app, autoUpdater, dialog, mainWindow });
    const initialCallback = process.argv.find(isAuthCallback);
    if (initialCallback) receiveAuthCallback(initialCallback);
    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) void mainWindow.loadURL(`${appOrigin}/`);
    });
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
  });
}
