const fs = require("node:fs");
const path = require("node:path");

const { releaseRepository } = require("./update-config.json");

function startAutoUpdates({ app, autoUpdater, dialog, mainWindow }) {
  if (process.platform !== "win32" || !app.isPackaged) return;

  // The portable ZIP does not have Squirrel's Update.exe. Only installed copies update.
  const updateExe = path.resolve(path.dirname(process.execPath), "..", "Update.exe");
  if (!fs.existsSync(updateExe)) return;

  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(releaseRepository || "")) {
    console.error("OMI automatic updates are not configured for this build.");
    return;
  }

  const feedUrl = `https://update.electronjs.org/${releaseRepository}/win32-${process.arch}/${app.getVersion()}`;
  autoUpdater.on("error", (error) => console.error("OMI update check failed:", error));
  autoUpdater.on("update-downloaded", () => {
    void dialog.showMessageBox(mainWindow, {
      type: "info",
      buttons: ["Reiniciar y actualizar", "Más tarde"],
      defaultId: 0,
      cancelId: 1,
      title: "Actualización de OMI lista",
      message: "La nueva versión de OMI se descargó.",
      detail: "Puedes actualizar ahora o cerrar y volver a abrir OMI más tarde.",
      noLink: true,
    }).then(({ response }) => {
      if (response === 0) autoUpdater.quitAndInstall();
    }).catch((error) => console.error("Could not show OMI update prompt:", error));
  });

  try {
    autoUpdater.setFeedURL({ url: feedUrl });
  } catch (error) {
    console.error("Could not configure OMI updates:", error);
    return;
  }

  const check = () => {
    try {
      void Promise.resolve(autoUpdater.checkForUpdates()).catch((error) => {
        console.error("OMI update check failed:", error);
      });
    } catch (error) {
      console.error("OMI update check failed:", error);
    }
  };

  // Squirrel holds the app files briefly after the first installation.
  setTimeout(check, process.argv.includes("--squirrel-firstrun") ? 30_000 : 10_000).unref();
  setInterval(check, 6 * 60 * 60 * 1000).unref();
}

module.exports = { startAutoUpdates };
