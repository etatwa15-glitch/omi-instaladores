const path = require('node:path');

module.exports = {
  packagerConfig: {
    asar: true,
    name: 'OMI',
    executableName: 'OMI',
    appBundleId: 'com.omi.app',
    icon: path.join(__dirname, 'electron', 'assets', 'omi.icns'),
    protocols: [{ name: 'OMI Auth', schemes: ['smbsystem'] }],
    ignore: (relativePath) => {
      if (!relativePath) return false;
      const topLevel = relativePath.replaceAll('\\', '/').split('/')[1];
      return !['package.json', 'electron', 'dist'].includes(topLevel);
    },
  },
  makers: [{ name: '@electron-forge/maker-zip', platforms: ['darwin'] }],
};
